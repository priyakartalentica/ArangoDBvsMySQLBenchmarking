package com.sql.pizzaomssql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaomssqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
